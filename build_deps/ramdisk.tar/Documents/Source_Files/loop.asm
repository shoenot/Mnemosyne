global _start

section .text
_start:
    hlt
